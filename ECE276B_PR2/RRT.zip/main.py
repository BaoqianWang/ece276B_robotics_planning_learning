import numpy as np
import time
import matplotlib.pyplot as plt; plt.ion()
from mpl_toolkits.mplot3d import Axes3D
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import pyrr
import numpy as np
from src.rrt.rrt import RRT
from src.search_space.search_space import SearchSpace
from src.utilities.plotting import Plot

def tic():
  return time.time()

def draw_block_list(ax,blocks):
  '''
  Subroutine used by draw_map() to display the environment blocks
  '''
  v = np.array([[0,0,0],[1,0,0],[1,1,0],[0,1,0],[0,0,1],[1,0,1],[1,1,1],[0,1,1]],dtype='float')
  f = np.array([[0,1,5,4],[1,2,6,5],[2,3,7,6],[3,0,4,7],[0,1,2,3],[4,5,6,7]])
  clr = blocks[:,6:]/255
  n = blocks.shape[0]
  d = blocks[:,3:6] - blocks[:,:3] 
  vl = np.zeros((8*n,3))
  fl = np.zeros((6*n,4),dtype='int64')
  fcl = np.zeros((6*n,3))
  for k in range(n):
    vl[k*8:(k+1)*8,:] = v * d[k] + blocks[k,:3]
    fl[k*6:(k+1)*6,:] = f + k*8
    fcl[k*6:(k+1)*6,:] = clr[k,:]
  
  if type(ax) is Poly3DCollection:
    ax.set_verts(vl[fl])
  else:
    pc = Poly3DCollection(vl[fl], alpha=0.25, linewidths=1, edgecolors='k')
    pc.set_facecolor(fcl)
    h = ax.add_collection3d(pc)
    return h



def collision_checking(startPoint, endPoint, box):
      # Check the collision between a line segement defined by a start point and end point and a axis aligned box.
  line1 = pyrr.line.create_from_points(startPoint, endPoint)
  line2 = pyrr.line.create_from_points(endPoint, startPoint)

  ray1 = pyrr.ray.create_from_line(line1)
  ray2 = pyrr.ray.create_from_line(line2)

  result1 = pyrr.geometric_tests.ray_intersect_aabb(ray1, box)
  result2 = pyrr.geometric_tests.ray_intersect_aabb(ray2, box)

  if (result1 is None or result2 is None):
     return 0
  return 1

def toc(tstart, nm=""):
  print('%s took: %s sec.\n' % (nm,(time.time() - tstart)))

def load_map(fname):
  '''
  Loads the bounady and blocks from map file fname.
  
  boundary = [['xmin', 'ymin', 'zmin', 'xmax', 'ymax', 'zmax','r','g','b']]
  
  blocks = [['xmin', 'ymin', 'zmin', 'xmax', 'ymax', 'zmax','r','g','b'],
            ...,
            ['xmin', 'ymin', 'zmin', 'xmax', 'ymax', 'zmax','r','g','b']]
  '''
  mapdata = np.loadtxt(fname,dtype={'names': ('type', 'xmin', 'ymin', 'zmin', 'xmax', 'ymax', 'zmax','r','g','b'),\
                                    'formats': ('S8','f', 'f', 'f', 'f', 'f', 'f', 'f','f','f')})
  blockIdx = mapdata['type'] == b'block'
  boundary = mapdata[~blockIdx][['xmin', 'ymin', 'zmin', 'xmax', 'ymax', 'zmax','r','g','b']].view('<f4').reshape(-1,11)[:,2:]
  blocks = mapdata[blockIdx][['xmin', 'ymin', 'zmin', 'xmax', 'ymax', 'zmax','r','g','b']].view('<f4').reshape(-1,11)[:,2:]
  return boundary, blocks


def runtest(mapfile, x_init, x_goal, verbose = True):
  '''
  This function:
   * load the provided mapfile
   * creates a motion planner
   * plans a path from start to goal
   * checks whether the path is collision free and reaches the goal
   * computes the path length as a sum of the Euclidean norm of the path segments
  '''
  # Load a map and instantiate a motion planner
  boundary, blocks = load_map(mapfile)
  X_dimensions = np.array([(boundary[0][0], boundary[0][3]), (boundary[0][1], boundary[0][4]), (boundary[0][2], boundary[0][5])])  # dimensions of Search Space
  # obstacles
  box1=blocks[0]
  Obstacles=np.array([(box1[0],box1[1],box1[2],box1[3],box1[4],box1[5])])
  for i in range(1,len(blocks)):
      box=blocks[i]
      tempTuple=np.array([(box[0],box[1],box[2],box[3],box[4],box[5])])
      Obstacles=np.vstack((Obstacles,tempTuple))

  Q = np.array([(8, 4)])  # length of tree edges
  r = .1  # length of smallest edge to check for intersection with obstacles
  max_samples = 102048  # max number of samples to take before timing out
  prc = 0.1  # probability of checking for a connection to goal
  t0 = tic()
  # create Search Space
  X = SearchSpace(X_dimensions, Obstacles)

  # create rrt_search
  rrt = RRT(X, Q, x_init, x_goal, max_samples, r, prc)
  path = rrt.rrt_search()
  toc(t0,"Planning")
  rx=[]
  ry=[]
  rz=[]
  if(path is None):
     print('No feasible path')
     return 0,0
  for i in range(len(path)):
     rx.append(path[i][0])
     ry.append(path[i][1])
     rz.append(path[i][2])


  
  
  #Concatenate the path
  path=np.vstack((np.asarray(rx),np.asarray(ry),np.asarray(rz))).T
  

 
  # TODO: You should verify whether the path actually intersects any of the obstacles in continuous space
  # TODO: You can implement your own algorithm or use an existing library for segment and 
  #       axis-aligned bounding box (AABB) intersection
  collision=0
  for i in range(len(rx)-1):
    for k in range(blocks.shape[0]):
      box = np.array([[blocks[k, 0], blocks[k, 1], blocks[k, 2]],
                      [blocks[k, 3], blocks[k, 4], blocks[k, 5]]])
      if collision_checking(path[i],path[i+1],box):
          collision=collision+1
  #collision = False
  print('The error is', sum((path[-1] - x_goal) ** 2))
  print('Number of collision', collision)
  goal_reached = sum((path[-1]-x_goal)**2) <= 0.1
  success = (not collision) and goal_reached
  pathlength = np.sum(np.sqrt(np.sum(np.diff(path,axis=0)**2,axis=1)))
  #Draw the environment and planned path
  fig = plt.figure()
  ax = fig.add_subplot(111, projection='3d')
  hs = ax.scatter(x_init[0],x_init[1],x_init[2],'ro',s=40,label='Start')
  hg = ax.scatter(x_goal[0],x_goal[1],x_goal[2],'go',s=40,label='End')
  hb = draw_block_list(ax,blocks)
  ax.plot(rx, ry, rz, label='Path')
  ax.plot(rx, ry, rz, 'ro', markersize=3, markeredgecolor='k',label='Path Node')
  #ax.plot(rx,ry,rz,'ro',markersize=3,markeredgecolor='k',label='Path')
  ax.set_xlabel('X')
  ax.set_ylabel('Y')
  ax.set_zlabel('Z')
  ax.set_xlim(boundary[0,0],boundary[0,3])
  ax.set_ylim(boundary[0,1],boundary[0,4])
  ax.set_zlim(boundary[0,2],boundary[0,5])
  plt.legend()
  plt.show(block=True) 
  return success,pathlength


def test_single_cube(verbose = True):
  print('Running single cube test...\n') 
  start = (2.3, 2.3, 1.3)
  goal = (7.0, 7.0, 5.5)
  success, pathlength = runtest('./maps/single_cube.txt', start, goal, verbose)
  print('Success: %r'%success)
  print('Path length: %d'%pathlength)
  print('\n')
  
  
def test_maze(verbose = False):
  print('Running maze test...\n') 
  start = (0.0, 0.0, 1.0)
  goal = (12.0, 12.0, 5.0)
  success, pathlength = runtest('./maps/maze.txt', start, goal, verbose)
  print('Success: %r'%success)
  print('Path length: %d'%pathlength)
  print('\n')

    
def test_window(verbose = False):
  print('Running window test...\n') 
  start = (0.2, -4.9, 0.2)
  goal = (6.0, 18.0, 3.0)
  success, pathlength = runtest('./maps/window.txt', start, goal, verbose)
  print('Success: %r'%success)
  print('Path length: %d'%pathlength)
  print('\n')

  
def test_tower(verbose = False):
  print('Running tower test...\n') 
  start = (2.5, 4.0, 0.5)
  goal = (4.0, 2.5, 19.5)
  success, pathlength = runtest('./maps/tower.txt', start, goal, verbose)
  print('Success: %r'%success)
  print('Path length: %d'%pathlength)
  print('\n')

     
def test_flappy_bird(verbose = False):
  print('Running flappy bird test...\n') 
  start = (0.5, 2.5, 5.5)
  goal = (19.0, 2.5, 5.5)
  success, pathlength = runtest('./maps/flappy_bird.txt', start, goal, verbose)
  print('Success: %r'%success)
  print('Path length: %d'%pathlength) 
  print('\n')

  
def test_room(verbose = False):
  print('Running room test...\n') 
  start = (1.0, 5.0, 1.5)
  goal = (9.0, 7.0, 1.5)
  success, pathlength = runtest('./maps/room.txt', start, goal, verbose)
  print('Success: %r'%success)
  print('Path length: %d'%pathlength)
  print('\n')


def test_monza(verbose = False):
  print('Running monza test...\n')
  start = (0.5, 1.0, 4.9)
  goal = (3.8, 1.0, 0.1)
  success, pathlength = runtest('./maps/monza.txt', start, goal, verbose)
  print('Success: %r'%success)
  print('Path length: %d'%pathlength)
  print('\n')


if __name__=="__main__":
  #test_single_cube()
  test_maze()
  #test_flappy_bird()
  #test_monza()
  #test_window()
  #test_tower()
  #test_room()

ECE 276B Planning&Learning Robotics
Project 1: Markov Decision Process and Dynamic Programming
Baoqian Wang

File Descriptions:

	1. envs: Folder that contains the environment files.
	2. gif: Folder that contains the generated gif files. 
	3. imgs: Folder that contains the images of the environment.
	4. doorkey.py: python script that implements dynamic programming for Door-Key problem,
		       which can be executed as main function.
	5. utils.py: provided by instructors. No modification is made.
	6. example.py: provided by instructors. No modification is made.